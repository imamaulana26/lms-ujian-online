﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('wordcount', 'en', {
    WordCount: 'Words:',
    WordCountRemaining: 'Words remaining',
    CharCount: 'Characters:',
    CharCountRemaining: 'Characters remaining',
    CharCountWithHTML: 'Character:',
    CharCountWithHTMLRemaining: 'Characters (with HTML) remaining',
    Paragraphs: 'Paragraphs:',
    ParagraphsRemaining: 'Paragraphs remaining',
    pasteWarning: 'Melebihi Batas Maksimal',
    Selected: 'Selected: ',
    title: 'Statistics'
});
